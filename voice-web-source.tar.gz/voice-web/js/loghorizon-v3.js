const $ = (selector, root = document) => root.querySelector(selector);

function showToast(message) {
  const toast = $('#toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('visible');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('visible'), 2400);
}

function translateDynamicText(element) {
  if (!element) return;
  const value = element.textContent.trim();
  const replacements = new Map([
    ['Join', 'Entrar na voz'],
    ['Leave', 'Sair da voz'],
    ['Mute', 'Silenciar'],
    ['Unmute', 'Ativar microfone'],
    ['Hold to Talk', 'Segure para falar'],
    ['Talking...', 'Falando…'],
    ['Bind Push-to-Talk', 'Definir atalho'],
    ['Clear Binding', 'Limpar'],
    ['Developer Tools ▼', 'Diagnóstico do navegador'],
    ['Developer Tools ▲', 'Diagnóstico do navegador'],
    ['Disconnected', 'Desconectado']
  ]);

  if (replacements.has(value)) {
    element.textContent = replacements.get(value);
  } else if (value.startsWith('Connected as ')) {
    element.textContent = `Conectado como ${value.slice('Connected as '.length)}`;
  } else if (value.startsWith('Bound to ')) {
    element.textContent = `Atalho: ${value.slice('Bound to '.length)}`;
  } else if (value.startsWith('No binding set.')) {
    element.textContent = 'Nenhum atalho configurado. Use o botão ou defina uma tecla.';
  } else if (value.startsWith('Waiting for input')) {
    element.textContent = 'Pressione uma tecla, botão do mouse ou controle. Esc cancela.';
  }
}

function updateConnectionUi(client) {
  const status = $('#status');
  const hint = $('#connectionHint');
  const input = $('#msgInput');
  const send = $('#messageButton');
  const connected = client?.webSocketController?.isConnected?.() === true;
  const text = status?.textContent?.toLowerCase() || '';

  status?.classList.remove('waiting', 'connecting', 'connected', 'disconnected', 'error');

  if (connected || text.includes('conectado como') || text.includes('connected as')) {
    status?.classList.add('connected');
    if (hint) hint.textContent = 'A voz acompanha a posição e a distância dos jogadores.';
  } else if (text.includes('conectando') || text.includes('reconect')) {
    status?.classList.add('connecting');
    if (hint) hint.textContent = 'Abrindo uma conexão segura com a sala de voz…';
  } else if (text.includes('erro') || text.includes('falha')) {
    status?.classList.add('error');
    if (hint) hint.textContent = 'Confira o diagnóstico e tente novamente.';
  } else if (text.includes('desconect')) {
    status?.classList.add('disconnected');
    if (hint) hint.textContent = 'A sessão foi encerrada. Você pode entrar novamente.';
  } else {
    status?.classList.add('waiting');
    if (hint) hint.textContent = 'Preencha os dados para começar.';
  }

  if (input) input.disabled = !connected;
  if (send) send.disabled = !connected;
}

function updateLogEmptyState() {
  const log = $('#log');
  const empty = $('#emptyLog');
  if (!log || !empty) return;
  empty.classList.toggle('hidden', log.textContent.trim().length > 0);
}

function getSelectedLabel(select) {
  return select?.selectedOptions?.[0]?.textContent?.trim() || 'Dispositivo padrão';
}

async function refreshDevices(client) {
  const button = $('#refreshDevices');
  if (button) {
    button.disabled = true;
    button.textContent = 'Atualizando…';
  }

  try {
    await client.ui.populateAudioDevices();
    $('#outputStateText').textContent = getSelectedLabel($('#speaker'));
    $('#micStateText').textContent = getSelectedLabel($('#mic'));
    showToast('Lista de dispositivos atualizada.');
  } catch (error) {
    console.error(error);
    showToast('Não foi possível atualizar os dispositivos.');
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = 'Atualizar dispositivos';
    }
  }
}

async function testMicrophone(client) {
  const button = $('#testMic');
  const indicator = $('#micIndicator');
  const state = $('#micStateText');

  if (client.webSocketController.isConnected()) {
    showToast('Saia da voz antes de executar o teste separado do microfone.');
    return;
  }

  if (!navigator.mediaDevices?.getUserMedia) {
    showToast('Este navegador não permite testar o microfone.');
    return;
  }

  button.disabled = true;
  const original = button.innerHTML;
  button.innerHTML = '<span>Testando…</span><small>Fale normalmente</small>';
  if (state) state.textContent = 'Ouvindo por 6 segundos';

  let stream;
  let context;
  let frame;
  try {
    const deviceId = $('#mic')?.value;
    stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        deviceId: deviceId ? { exact: deviceId } : undefined,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      }
    });

    const AudioContextCtor = window.AudioContext || window.webkitAudioContext;
    context = new AudioContextCtor();
    const source = context.createMediaStreamSource(stream);
    const analyser = context.createAnalyser();
    analyser.fftSize = 512;
    source.connect(analyser);
    const data = new Uint8Array(analyser.frequencyBinCount);
    const started = performance.now();
    let peak = 0;

    await new Promise(resolve => {
      const tick = now => {
        analyser.getByteFrequencyData(data);
        const average = data.reduce((sum, value) => sum + value, 0) / Math.max(1, data.length);
        peak = Math.max(peak, average);
        indicator?.classList.toggle('active', average > 4);
        if (state) state.textContent = average > 4 ? 'Som detectado' : 'Fale para testar';
        if (now - started >= 6000) return resolve();
        frame = requestAnimationFrame(tick);
      };
      frame = requestAnimationFrame(tick);
    });

    if (peak > 4) {
      showToast('Microfone funcionando: som detectado.');
      if (state) state.textContent = 'Microfone funcionando';
    } else {
      showToast('O microfone abriu, mas nenhum som foi detectado.');
      if (state) state.textContent = 'Nenhum som detectado';
    }
  } catch (error) {
    console.error(error);
    showToast('Falha ao acessar o microfone. Verifique a permissão.');
    if (state) state.textContent = 'Permissão ou dispositivo indisponível';
  } finally {
    cancelAnimationFrame(frame);
    indicator?.classList.remove('active');
    stream?.getTracks().forEach(track => track.stop());
    await context?.close?.();
    button.disabled = false;
    button.innerHTML = original;
  }
}

function createToneUrl() {
  const sampleRate = 44100;
  const duration = 0.35;
  const samples = Math.floor(sampleRate * duration);
  const buffer = new ArrayBuffer(44 + samples * 2);
  const view = new DataView(buffer);
  const write = (offset, value) => [...value].forEach((char, index) => view.setUint8(offset + index, char.charCodeAt(0)));
  write(0, 'RIFF');
  view.setUint32(4, 36 + samples * 2, true);
  write(8, 'WAVE');
  write(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  write(36, 'data');
  view.setUint32(40, samples * 2, true);
  for (let i = 0; i < samples; i++) {
    const fade = Math.min(1, i / 500, (samples - i) / 900);
    const sample = Math.sin(2 * Math.PI * 660 * i / sampleRate) * 0.24 * fade;
    view.setInt16(44 + i * 2, sample * 0x7fff, true);
  }
  return URL.createObjectURL(new Blob([buffer], { type: 'audio/wav' }));
}

async function testOutput() {
  const button = $('#testSound');
  const speaker = $('#speaker');
  const audio = new Audio();
  const url = createToneUrl();
  button.disabled = true;

  try {
    if (typeof audio.setSinkId === 'function' && speaker?.value) {
      await audio.setSinkId(speaker.value);
    }
    audio.src = url;
    await audio.play();
    showToast('Som de teste reproduzido.');
  } catch (error) {
    console.error(error);
    showToast('O navegador bloqueou o som. Clique novamente ou confira a saída.');
  } finally {
    audio.addEventListener('ended', () => URL.revokeObjectURL(url), { once: true });
    setTimeout(() => {
      URL.revokeObjectURL(url);
      button.disabled = false;
    }, 1000);
  }
}

async function copyDiagnostics(client) {
  const runtime = client.audioController.getAudioRuntime();
  const text = [
    'LOG HORIZON VOICE WEB — DIAGNÓSTICO',
    `Data: ${new Date().toLocaleString('pt-BR')}`,
    `URL: ${location.href}`,
    `Navegador: ${navigator.userAgent}`,
    `Contexto seguro: ${window.isSecureContext ? 'sim' : 'não'}`,
    `Conectado: ${client.webSocketController.isConnected() ? 'sim' : 'não'}`,
    `AudioContext: ${runtime.audioContextSupported ? 'sim' : 'não'}`,
    `AudioWorklet: ${runtime.workletSupported ? 'sim' : 'não'}`,
    `Captura de microfone: ${runtime.canCaptureMic ? 'sim' : 'não'}`,
    `Seleção de saída: ${runtime.canSelectOutput ? 'sim' : 'não'}`,
    `Microfone: ${getSelectedLabel($('#mic'))}`,
    `Saída: ${getSelectedLabel($('#speaker'))}`,
    '',
    'Últimos eventos:',
    ...($('#log')?.textContent || '').trim().split('\n').slice(-20)
  ].join('\n');

  try {
    await navigator.clipboard.writeText(text);
    showToast('Diagnóstico copiado.');
  } catch {
    const area = document.createElement('textarea');
    area.value = text;
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    area.remove();
    showToast('Diagnóstico copiado.');
  }
}

function setupTranslations() {
  const elements = [
    $('#joinbtn'), $('#muteBtn'), $('#pushToTalkBtn'), $('#pushToTalkFullscreenBtn'),
    $('#bindPttBtn'), $('#clearPttBtn'), $('#pttBindingLabel'), $('#devToggle'), $('#status')
  ].filter(Boolean);

  for (const element of elements) {
    translateDynamicText(element);
    new MutationObserver(() => translateDynamicText(element)).observe(element, { childList: true, characterData: true, subtree: true });
  }
}

function setupStatusObservers(client) {
  const status = $('#status');
  const log = $('#log');
  const mic = $('#mic');
  const speaker = $('#speaker');

  const update = () => {
    translateDynamicText(status);
    updateConnectionUi(client);
  };

  new MutationObserver(update).observe(status, { childList: true, characterData: true, subtree: true });
  new MutationObserver(updateLogEmptyState).observe(log, { childList: true, characterData: true, subtree: true });

  mic?.addEventListener('change', () => { $('#micStateText').textContent = getSelectedLabel(mic); });
  speaker?.addEventListener('change', () => { $('#outputStateText').textContent = getSelectedLabel(speaker); });
  $('#micIndicator')?.addEventListener('animationstart', () => { $('#micStateText').textContent = 'Transmitindo voz'; });

  update();
  updateLogEmptyState();
}

function setupForm(client) {
  const form = $('#joinForm');
  const username = $('#username');
  const remember = $('#rememberUsername');
  const saved = localStorage.getItem('lhVoiceUsername');

  if (saved) {
    username.value = saved;
    remember.checked = true;
  }

  form.addEventListener('submit', () => {
    if (!client.webSocketController.isConnected()) {
      $('#status').textContent = 'Conectando…';
      if (remember.checked) localStorage.setItem('lhVoiceUsername', username.value.trim());
      else localStorage.removeItem('lhVoiceUsername');
    }
  }, { capture: true });

  $('#togglePassword').addEventListener('click', event => {
    const password = $('#password');
    const showing = password.type === 'text';
    password.type = showing ? 'password' : 'text';
    event.currentTarget.setAttribute('aria-label', showing ? 'Mostrar senha' : 'Ocultar senha');
  });
}

function setupControls(client) {
  $('#refreshDevices').addEventListener('click', () => refreshDevices(client));
  $('#testMic').addEventListener('click', () => testMicrophone(client));
  $('#testSound').addEventListener('click', testOutput);
  $('#clearLog').addEventListener('click', () => {
    $('#log').textContent = '';
    updateLogEmptyState();
    showToast('Atividade limpa.');
  });
  $('#copyDiagnostics').addEventListener('click', () => copyDiagnostics(client));

  $('#msgInput').addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      if (!event.currentTarget.disabled) $('#messageButton').click();
    }
  });

  const devToggle = $('#devToggle');
  const devContent = $('#devContent');
  devToggle.addEventListener('click', () => {
    requestAnimationFrame(() => {
      const expanded = !devContent.classList.contains('dev-hidden');
      devToggle.setAttribute('aria-expanded', String(expanded));
      translateDynamicText(devToggle);
    });
  });
}

function updateRuntimeDetails(client) {
  const runtime = client.audioController.getAudioRuntime();
  $('#secureContextValue').textContent = window.isSecureContext ? 'Sim' : 'Não';
  $('#captureSupportValue').textContent = runtime.canCaptureMic ? 'Disponível' : 'Limitada';
  $('#sinkSupportValue').textContent = runtime.canSelectOutput ? 'Disponível' : 'Padrão do sistema';
  $('#outputSupportChip').textContent = runtime.canSelectOutput ? 'SELECIONÁVEL' : 'PADRÃO';
  $('#outputStateText').textContent = getSelectedLabel($('#speaker'));
  $('#micStateText').textContent = getSelectedLabel($('#mic'));

  if (!window.isSecureContext) {
    const log = $('#log');
    log.textContent += '\n[Log Horizon] Aviso: a página não está em HTTPS; alguns navegadores podem limitar o microfone.';
  }
}

export function initLogHorizonUI(client) {
  setupTranslations();
  setupForm(client);
  setupControls(client);
  setupStatusObservers(client);
  updateRuntimeDetails(client);
  document.body.classList.add('client-ready');
}
