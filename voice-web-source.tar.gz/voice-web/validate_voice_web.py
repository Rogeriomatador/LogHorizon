from html.parser import HTMLParser
from pathlib import Path

REQUIRED = {
    'form', 'form.join', 'form.status', 'form.username', 'form.password',
    'audio.speaker', 'audio.mic', 'audio.mute', 'audio.indicator',
    'ptt.mic-card', 'ptt.mode', 'ptt.card', 'ptt.binding-controls',
    'ptt.bind', 'ptt.clear', 'ptt.binding-label', 'ptt.controls',
    'ptt.button', 'ptt.fullscreen', 'ptt.overlay', 'ptt.overlay-button',
    'ptt.overlay-exit', 'ptt.allow-background', 'dev.toggle', 'dev.content',
    'chat.log', 'chat.input', 'chat.send'
}

class ContractParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.data_svg = []
        self.ids = []
        self.meta_build = None

    def handle_starttag(self, tag, attrs):
        data = dict(attrs)
        if 'data-svg' in data:
            self.data_svg.append(data['data-svg'])
        if 'id' in data:
            self.ids.append(data['id'])
        if tag == 'meta' and data.get('name') == 'build-id':
            self.meta_build = data.get('content')

html = Path('voice-web/loghorizon.html').read_text(encoding='utf-8')
parser = ContractParser()
parser.feed(html)

missing = sorted(REQUIRED - set(parser.data_svg))
duplicates = sorted({x for x in parser.data_svg if parser.data_svg.count(x) > 1})
id_duplicates = sorted({x for x in parser.ids if parser.ids.count(x) > 1})

assert not missing, f'Missing data-svg contracts: {missing}'
assert not duplicates, f'Duplicate data-svg contracts: {duplicates}'
assert not id_duplicates, f'Duplicate element ids: {id_duplicates}'
assert parser.meta_build == 'f5b91f7', f'Unexpected build id: {parser.meta_build}'
assert 'window.BUILD_ID = "f5b91f7"' in html
assert "SvgBuilder.fromDocument().build()" in html
assert Path('voice-web/css/loghorizon-v3.css').stat().st_size > 5000
assert Path('voice-web/js/loghorizon-v3.js').stat().st_size > 5000
print(f'OK: {len(REQUIRED)} required contracts, {len(parser.ids)} unique ids, build f5b91f7')
